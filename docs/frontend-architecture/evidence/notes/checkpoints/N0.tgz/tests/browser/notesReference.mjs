import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { chromium } from 'playwright';

const origin = process.env.ODYSSEUS_TEST_STATIC_ORIGIN;
const evidence = process.env.NOTES_EVIDENCE_DIR;
const browser = await chromium.launch({ headless: true });
try {
  for (const mobile of [false, true]) {
    const context = await browser.newContext({ viewport: mobile ? { width: 390, height: 844 } : { width: 1440, height: 1000 }, hasTouch: mobile, isMobile: mobile });
    const page = await context.newPage();
    const requests = [];
    const notes = [
      { id: 'plain', title: 'Reference note', note_type: 'note', content: 'Visit https://example.org and keep this draft.', label: 'work', sort_order: 0 },
      { id: 'todo', title: 'Reference checklist', note_type: 'todo', items: [{ text: 'First task', done: false }, { text: 'Second task', done: true }], sort_order: 1 },
      { id: 'goal', title: 'Reference goal', note_type: 'goal', content: 'A bounded goal', items: [{ text: 'Next step', done: false }], sort_order: 2 },
    ];
    await page.route('**/api/**', async route => {
      const request = route.request();
      requests.push({ url: new URL(request.url()).pathname, method: request.method(), body: request.postData() });
      const id = new URL(request.url()).pathname.split('/').at(-1);
      if (request.method() === 'PUT') Object.assign(notes.find(n => n.id === id) || {}, request.postDataJSON());
      await route.fulfill({ json: request.method() === 'GET' ? { notes } : notes.find(n => n.id === id) || {} });
    });
    await page.goto(`${origin}/static/js/panels.js`);
    const shell = fs.readFileSync(new URL('../../static/index.html', import.meta.url), 'utf8');
    const styles = [...shell.matchAll(/<link[^>]+rel="stylesheet"[^>]*>/g)].map(m => m[0]).join('\n');
    await page.setContent(`<html><head>${styles}</head><body><div id="chat-container"></div><button id="tool-notes-btn"><span id="notes-new-note-btn"></span></button><button id="rail-notes"></button></body></html>`);
    await page.evaluate(() => {
      localStorage.setItem('odysseus-notes-first-open-hint-v1', '1');
      window.referenceIntervals = [];
      const interval = window.setInterval.bind(window);
      window.setInterval = (fn, ms, ...args) => { const id = interval(fn, ms, ...args); window.referenceIntervals.push({ id, ms }); return id; };
    });
    const publicAPI = await page.evaluate(async () => {
      const mod = await import('/static/js/notes.js?v=20260911notesselectioncancel1');
      const again = await import('/static/js/notes.js?v=20260911notesselectioncancel1');
      window.referenceNotes = mod;
      mod.openPanel();
      return { names: Object.keys(mod).sort(), defaults: Object.keys(mod.default).sort(), singleton: again === mod, bridge: window.notesModule === mod.default, aliases: mod.openNotes === mod.openPanel && mod.closeNotes === mod.closePanel && mod.isNotesOpen === mod.isPanelOpen && mod.default.openNotes === mod.openPanel };
    });
    assert.equal(publicAPI.singleton && publicAPI.bridge && publicAPI.aliases, true);
    assert.deepEqual(publicAPI.names, ['closeNotes', 'closePanel', 'default', 'dismissFiredReminderDot', 'isNotesOpen', 'isPanelOpen', 'newNote', 'openNote', 'openNotes', 'openPanel', 'refreshDueBadge', 'togglePanel']);
    assert.deepEqual(publicAPI.defaults, ['closeNotes', 'closePanel', 'isNotesOpen', 'isPanelOpen', 'newNote', 'openNote', 'openNotes', 'openPanel', 'refreshDueBadge', 'togglePanel']);
    await page.locator('.note-card').first().waitFor();
    assert.equal(await page.locator('.note-card').count(), 3);
    if (evidence) await page.screenshot({ path: path.join(evidence, mobile ? 'notes-mobile.png' : 'notes-desktop.png'), fullPage: true });
    await page.locator('#notes-search').fill('checklist');
    assert.equal(await page.locator('.note-card').count(), 1);
    await page.locator('#notes-search').fill('');
    await page.locator('#notes-select-btn').click();
    await page.locator('.note-card-cb').first().check();
    await page.locator('#notes-send-agent').click();
    assert.equal(await page.locator('.note-card-selectmode').count(), 3, 'rejected selection stays selected');
    await page.evaluate(() => window.addEventListener('odysseus:notes-context-selected', e => { window.referenceSelected = e.detail.noteIds; e.detail.accepted = true; }, { once: true }));
    await page.locator('#notes-send-agent').click();
    assert.equal(await page.locator('.note-card-selectmode').count(), 0);
    assert.equal((await page.evaluate(() => window.referenceSelected)).length, 1);
    await page.locator('#notes-search').fill('checklist');
    await page.evaluate(() => window.referenceNotes.closePanel());
    await page.locator('#notes-pane').waitFor({ state: 'detached' });
    await page.evaluate(() => window.referenceNotes.openPanel());
    await page.locator('.note-card').first().waitFor();
    assert.equal(await page.locator('#notes-search').inputValue(), '');
    assert.equal(await page.locator('.note-card').count(), 3);
    if (mobile) await page.locator('[data-note-id="plain"] .note-card-title').tap();
    else await page.locator('[data-note-id="plain"] .note-card-title').click();
    await page.locator('.note-form-content').fill('Recovered draft');
    assert.equal(await page.evaluate(() => JSON.parse(localStorage.getItem('odysseus-note-draft-plain')).content), 'Recovered draft');
    await page.waitForFunction(() => !localStorage.getItem('odysseus-note-draft-plain'));
    assert.ok(requests.some(r => r.method === 'PUT' && JSON.parse(r.body).content === 'Recovered draft'));
    await page.evaluate(() => window.referenceNotes.closePanel());
    await context.close();
    console.log(JSON.stringify({ mobile, ...publicAPI, requests: requests.length }));
  }
} finally { await browser.close(); }
